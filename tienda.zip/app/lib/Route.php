<?php
namespace app\lib;

class Route 
{
  use ProcessRoute;  
}